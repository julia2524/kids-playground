import React, { useEffect, useRef, useState } from "react";

import { LayoutChangeEvent, View } from "react-native";

import styled from "styled-components/native";

import { ColorSortingObject } from "../../types/Classification/Color/colorSotringTypes";

import ColorSortingObjectComponent, {
  BUBBLE_EXTRA_SIZE,
  DragBounds,
  StickerPlacement,
  TargetRects,
} from "./ColorSortingObjectComponent";

type ColorSortingObjectBoardProps = {
  objects: ColorSortingObject[];

  selectedObjectId: string | null;

  placedObjectIds: string[];

  onObjectPress: (objectId: string) => void;
  footerRef: React.RefObject<View | null>;
  getTargetRects: (callback: (rects: TargetRects) => void) => void;
  onCorrectDrop: (
    objectId: string,
    targetColorId: string,
    placement: StickerPlacement,
  ) => void;
  onWrongDrop?: (objectId: string) => void;
  tutorialRef?: (objectId: string, node: View | null) => void;
  onObjectGrab?: (objectId: string) => void;
  onObjectSizeChange?: (size: number) => void;
};

// ObjectBoard 스타일과 맞춰야 하는 값
const BOARD_BORDER = 2;
const BOARD_PADDING_X = 8;

// ============================================================
// Grid
// ============================================================

const getGridColumns = (count: number) => {
  if (count <= 4) return 2;
  if (count <= 6) return 3;
  if (count <= 8) return 3;
  if (count === 9) return 3;
  if (count === 10) return 5;
  return 4;
};

// ============================================================
// Object Size
// ============================================================

const getBaseObjectSize = (columns: number) => {
  if (columns <= 2) return 96;
  if (columns === 3) return 84;
  if (columns === 4) return 72;
  return 60;
};

const getObjectSize = ({
  columns,
  rows,
  boardWidth,
  boardHeight,
}: {
  columns: number;
  rows: number;
  boardWidth: number;
  boardHeight: number;
}) => {
  const baseSize = getBaseObjectSize(columns);

  if (!boardWidth || !boardHeight) {
    return baseSize;
  }

  const horizontalPadding = 16;
  const verticalPadding = 24;

  const horizontalGap = 8;
  const verticalGap = 8;

  const availableWidth =
    boardWidth - horizontalPadding - horizontalGap * (columns - 1);

  const availableHeight =
    boardHeight - verticalPadding - verticalGap * (rows - 1);

  const widthBasedSize = availableWidth / columns - 12;

  const heightBasedSize = availableHeight / rows - 12;

  return Math.max(48, Math.min(baseSize, widthBasedSize, heightBasedSize));
};

// ============================================================
// Component
// ============================================================
const DRAG_EDGE_OVERFLOW = 10;
export default function ColorSortingObjectBoard({
  objects,
  selectedObjectId,
  placedObjectIds,
  onObjectPress,
  footerRef,
  getTargetRects,
  onCorrectDrop,
  onWrongDrop,
  tutorialRef,
  onObjectGrab,
  onObjectSizeChange,
}: ColorSortingObjectBoardProps) {
  // ==========================================================
  // Board 실제 크기
  // ==========================================================

  const [boardSize, setBoardSize] = useState({
    width: 0,
    height: 0,
  });

  const boardRef = useRef<any>(null);
  const [draggingObjectId, setDraggingObjectId] = useState<string | null>(null);

  // "마지막에 잡은 오브젝트가 위"가 되도록 쌓임 순서를 기억한다
  const zCounter = useRef(0);
  const [zOrder, setZOrder] = useState<Record<string, number>>({});

  // 새 문제가 들어오면 쌓임 순서 초기화
  useEffect(() => {
    zCounter.current = 0;
    setZOrder({});
  }, [objects]);

  const getDragBounds = (callback: (bounds: DragBounds) => void) => {
    const boardNode = boardRef.current as any;
    const footerNode = footerRef.current as any;

    if (boardNode && typeof boardNode.measureInWindow === "function") {
      boardNode.measureInWindow(
        (bx: number, by: number, bw: number, bh: number) => {
          if (footerNode && typeof footerNode.measureInWindow === "function") {
            footerNode.measureInWindow(
              (_fx: number, fy: number, _fw: number, fh: number) => {
                callback({
                  left: bx - DRAG_EDGE_OVERFLOW,
                  right: bx + bw + DRAG_EDGE_OVERFLOW,
                  top: by - DRAG_EDGE_OVERFLOW,
                  bottom: fy + fh,
                  board: {
                    left: bx,
                    right: bx + bw,
                    top: by,
                    bottom: by + bh,
                  },
                });
              },
            );
          }
        },
      );
    }
  };

  // ==========================================================
  // Grid 계산
  // ==========================================================

  const objectColumns = getGridColumns(objects.length);

  const objectRows: ColorSortingObject[][] = [];

  for (let i = 0; i < objects.length; i += objectColumns) {
    objectRows.push(objects.slice(i, i + objectColumns));
  }

  const rowCount = objectRows.length;

  // ==========================================================
  // 실제 Board 크기에 맞춰 Object 크기 계산
  // ==========================================================

  const objectSize = getObjectSize({
    columns: objectColumns,
    rows: rowCount,
    boardWidth: boardSize.width,
    boardHeight: boardSize.height,
  });

  useEffect(() => {
    if (boardSize.width > 0 && boardSize.height > 0) {
      onObjectSizeChange?.(objectSize);
    }
  }, [objectSize, boardSize.width, boardSize.height]);
  3;

  // ==========================================================
  // 슬롯 위치 계산 (기존 row + space-evenly 레이아웃과 같은 배치)
  // 오브젝트는 모두 보드의 직계 자식으로 absolute 배치한다.
  // -> 다른 행으로 옮겨도 보드 영역 안에 있으므로 다시 잡을 수 있다.
  // ==========================================================

  const bubbleSize = objectSize + BUBBLE_EXTRA_SIZE;
  const innerWidth = Math.max(0, boardSize.width - BOARD_BORDER * 2);
  const innerHeight = Math.max(0, boardSize.height - BOARD_BORDER * 2);
  const cellWidth = (innerWidth - BOARD_PADDING_X * 2) / objectColumns;
  const rowGap = Math.max(
    0,
    (innerHeight - rowCount * bubbleSize) / (rowCount + 1),
  );
  const isReady = boardSize.width > 0 && boardSize.height > 0;

  // ==========================================================
  // Board Layout
  // ==========================================================

  const handleBoardLayout = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;

    setBoardSize((prev) => {
      if (prev.width === width && prev.height === height) {
        return prev;
      }

      return {
        width,
        height,
      };
    });
  };

  // ==========================================================
  // Render
  // ==========================================================

  return (
    <ObjectBoard
      ref={boardRef}
      collapsable={false}
      onLayout={handleBoardLayout}
      isDragging={draggingObjectId !== null}
    >
      {isReady &&
        objectRows.map((row, rowIndex) => {
          const missing = objectColumns - row.length;

          return row.map((object, colIndex) => {
            const cellLeft =
              BOARD_PADDING_X +
              (missing * cellWidth) / 2 +
              colIndex * cellWidth;
            const slotLeft = cellLeft + (cellWidth - bubbleSize) / 2;
            const slotTop = rowGap * (rowIndex + 1) + rowIndex * bubbleSize;

            return (
              <ColorSortingObjectComponent
                key={object.id}
                object={object}
                objectSize={objectSize}
                slotLeft={slotLeft}
                slotTop={slotTop}
                zIndex={zOrder[object.id] ?? 0}
                isSelected={selectedObjectId === object.id}
                isPlaced={placedObjectIds.includes(object.id)}
                onPress={() => onObjectPress(object.id)}
                getDragBounds={getDragBounds}
                getTargetRects={getTargetRects}
                onDragStart={() => {
                  const next = ++zCounter.current;
                  setZOrder((prev) => ({ ...prev, [object.id]: next }));
                  setDraggingObjectId(object.id);
                  onObjectGrab?.(object.id);
                }}
                onDragEnd={() => setDraggingObjectId(null)}
                onCorrectDrop={onCorrectDrop}
                onWrongDrop={onWrongDrop}
                tutorialRef={tutorialRef}
              />
            );
          });
        })}
    </ObjectBoard>
  );
}

// ============================================================
// Styled Components
// ============================================================

// elevation은 Android에서 반투명 배경 + border-radius를 따라 회색 그림자선을 만들 수 있어 쓰지 않는다.
const ObjectBoard = styled.View<{
  isDragging?: boolean;
}>`
  flex: 1.2;

  margin-top: 12px;
  margin-bottom: 14px;

  background-color: rgba(255, 255, 255, 0.85);

  border-radius: 26px;
  border-width: ${BOARD_BORDER}px;
  border-color: rgba(255, 255, 255, 0.95);

  z-index: ${(p) => (p.isDragging ? 100 : 1)};
`;
