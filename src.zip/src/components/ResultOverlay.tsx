import React from "react";
import Ionicons from "@expo/vector-icons/Ionicons";
import styled from "styled-components/native";
import { I18nManager, TouchableOpacity } from "react-native";

import { AppText } from "../utils/AppText";
import UfoLevelBadge from "./UfoLevelBadge";
import { colors } from "../design-system/tokens/colors";

import { triggerHaptic } from "../utils/haptic";
import GameRewardBadge from "./common/GameRewardBadge";
import i18n from "../i18n";
import { useLanguage } from "../context/LangaugeContext";
import { stopEarnedNotes } from "../utils/sound";
import { useBackgroundMusic } from "../utils/BackgroundMusicContext";

// ============================================================
// Component Props Definition
// ============================================================
type ResultOverlayProps = {
  level: number;
  earnedStars: number;
  isLastLevel: boolean;
  gameType?:
    | "color"
    | "shape"
    | "category"
    | "size"
    | "pattern"
    | "puzzle"
    | "maze";

  onHome: () => void;
  onRestart: () => void;
  onNextLevel: () => void;
  onGoRoadmap: () => void;
};

export default function ResultOverlay({
  level,
  earnedStars,
  isLastLevel,
  gameType = "color",
  onHome,
  onRestart,
  onNextLevel,
  onGoRoadmap,
}: ResultOverlayProps) {
  useLanguage();
  const { playThemeBGM } = useBackgroundMusic();

  // 아랍권(RTL) 여부 확인
  const isRTL = I18nManager.isRTL;

  const handleGoRoadPress = () => {
    triggerHaptic("light");
    stopEarnedNotes();
    onGoRoadmap?.();
  };
  const handleRestartPress = () => {
    triggerHaptic("light");
    stopEarnedNotes();
    onRestart?.();
  };
  const handleNextLevelPress = () => {
    triggerHaptic("light");
    stopEarnedNotes();
    onNextLevel?.();
  };
  const handleHomePress = () => {
    triggerHaptic("light");
    stopEarnedNotes();

    playThemeBGM("main");
    onHome?.();
  };

  // ⭐ 별 5개를 표시
  const starOffsets = [18, 6, 0, 6, 18];

  return (
    <ResultOverlayContainer>
      <ResultCard>
        <Inner>
          {/* ================================================= */}
          {/* 닫기 */}
          {/* ================================================= */}
          <CloseButton onPress={handleGoRoadPress} activeOpacity={0.7}>
            <Ionicons name="close" size={24} color={colors.brand.primary} />
          </CloseButton>

          {/* ================================================= */}
          {/* 🚀 UFO */}
          {/* ================================================= */}
          <UfoWrapper>
            <UfoLevelBadge size={300} floating />
            <LevelText>{i18n.t("result_level_format", { level })}</LevelText>
          </UfoWrapper>

          {/* ================================================= */}
          {/* ⭐ 획득한 별 */}
          {/* ================================================= */}
          <StarSection>
            <StarRow>
              {Array.from({ length: 5 }).map((_, index) => {
                const starPosition = index + 1;

                let type: "full" | "half" | "empty" = "empty";

                if (earnedStars >= starPosition) {
                  type = "full";
                } else if (earnedStars >= starPosition - 0.5) {
                  type = "half";
                }

                return (
                  <StarWrapper
                    key={index}
                    style={{ marginTop: starOffsets[index] }}
                  >
                    <GameRewardBadge
                      gameType={gameType}
                      type={type}
                      size={42}
                    />
                  </StarWrapper>
                );
              })}
            </StarRow>
          </StarSection>

          {/* ================================================= */}
          {/* 성공 문구 */}
          {/* ================================================= */}
          <ResultTitle>{i18n.t("result_title")}</ResultTitle>

          {/* ================================================= */}
          {/* 버튼 */}
          {/* ================================================= */}
          <ButtonRow>
            {/* 다시하기 */}
            <ActionButton
              variant="secondary"
              onPress={handleRestartPress}
              activeOpacity={0.85}
            >
              <Ionicons name="refresh" size={26} color={colors.white} />
            </ActionButton>

            {/* 다음 레벨 */}
            {!isLastLevel && (
              <ActionButton
                variant="primary"
                onPress={handleNextLevelPress}
                activeOpacity={0.85}
              >
                <Ionicons
                  name={isRTL ? "arrow-back" : "arrow-forward"}
                  size={26}
                  color={colors.white}
                />
              </ActionButton>
            )}
          </ButtonRow>

          {/* ================================================= */}
          {/* 홈 */}
          {/* ================================================= */}
          <HomeButton onPress={handleHomePress} activeOpacity={0.85}>
            <Ionicons name="home" size={20} color={colors.white} />
          </HomeButton>
        </Inner>
      </ResultCard>
    </ResultOverlayContainer>
  );
}

// ============================================================
// STYLES
// ============================================================

const ResultOverlayContainer = styled.View`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(41, 38, 61, 0.48);
  align-items: center;
  justify-content: center;
  padding: 24px;
  z-index: 999;
  elevation: 999;
`;

const ResultCard = styled.View`
  width: 88%;
  max-width: 370px;
  background-color: ${colors.softBlue};
  border-radius: 34px;
  padding: 7px;
  border-width: 3px;
  border-color: ${colors.brand.primary};
  elevation: 15;
  shadow-color: ${colors.brand.primary};
  shadow-offset: 0px 7px;
  shadow-opacity: 0.22;
  shadow-radius: 12px;
  position: relative;
`;

const Inner = styled.View`
  width: 100%;
  background-color: ${colors.white};
  border-radius: 28px;
  padding: 24px 20px 20px;
  align-items: center;
`;

const UfoWrapper = styled.View`
  width: 100%;
  height: 150px;
  align-items: center;
  justify-content: center;
  margin-top: -100px;
  position: relative;
  z-index: 10;
`;

const LevelText = styled(AppText)`
  font-family: ${(props) => props.theme.fontFamily};
  position: absolute;
  top: 40px;
  ${({ theme }) => {
    const t = theme.typography.h3;
    return `
      font-size: ${t.fontSize}px;
      line-height: ${t.lineHeight}px;
      font-weight: 900;
    `;
  }}
  color: ${colors.brand.primary};
  text-align: center;
`;

const StarSection = styled.View`
  width: 100%;
  align-items: center;
`;

const StarRow = styled.View`
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  width: 100%;
  margin-bottom: 12px;
`;

const StarWrapper = styled.View`
  margin-left: 1px;
  margin-right: 1px;
  align-items: center;
  justify-content: center;
`;

const ResultTitle = styled(AppText)`
  font-family: ${(props) => props.theme.fontFamily};
  ${({ theme }) => {
    const t = theme.typography.h2;
    return `
      font-size: ${t.fontSize}px;
      line-height: ${t.lineHeight}px;
      font-weight: 900;
    `;
  }}
  color: ${colors.brand.primary};
  text-align: center;
  margin-top: 2px;
`;

const ButtonRow = styled.View`
  flex-direction: row;
  width: 100%;
  gap: 12px;
  margin-top: 18px;
`;

const ActionButton = styled(TouchableOpacity)<{
  variant: "primary" | "secondary";
}>`
  flex: 1;
  min-height: 56px;
  border-radius: 28px;
  align-items: center;
  justify-content: center;
  flex-direction: row;
  gap: 6px;

  background-color: ${(props) =>
    props.variant === "primary"
      ? colors.feedback.success
      : colors.feedback.retry};

  border-width: 2px;
  border-color: ${(props) =>
    props.variant === "primary" ? "#6AC8A3" : "#FFC875"};

  border-bottom-width: 5px;
  border-bottom-color: ${(props) =>
    props.variant === "primary" ? "#238B5E" : "#D98800"};

  elevation: 5;
`;

const HomeButton = styled(TouchableOpacity)`
  width: 100%;
  height: 48px;
  margin-top: 10px;
  border-radius: 24px;
  background-color: ${colors.brand.primary};
  align-items: center;
  justify-content: center;
  flex-direction: row;
  gap: 7px;

  border-width: 2px;
  border-color: #9d84ff;

  border-bottom-width: 4px;
  border-bottom-color: #5a3cd1;

  elevation: 4;
`;

const CloseButton = styled(TouchableOpacity)`
  position: absolute;
  top: 8px;
  right: 8px;
  width: 36px;
  height: 36px;
  border-radius: 18px;
  background-color: ${colors.white};
  align-items: center;
  justify-content: center;
  z-index: 30;

  border-width: 1.5px;
  border-color: ${colors.border.default};

  elevation: 5;
`;
