import * as React from "react";

import Svg, { G, Rect } from "react-native-svg";

import type { SvgProps } from "react-native-svg";

// 기존 퍼즐판과 조각이 공유하는 좌표계입니다.
export const FLAG_VIEW_BOX = "0 0 240 180";

type FlagProps = Omit<SvgProps, "children" | "viewBox" | "preserveAspectRatio">;

// 이미 Svg가 있는 퍼즐 장면에서는 도형만 따로 넣을 수 있습니다.
export const ROFlagArtwork = React.memo(function ROFlagArtwork() {
  return (
    <G>
      {/* 왼쪽 파란색 */}
      <Rect x={0} y={0} width={80} height={180} fill="#002B7F" />

      {/* 중앙 노란색 */}
      <Rect x={80} y={0} width={80} height={180} fill="#FCD116" />

      {/* 오른쪽 빨간색 */}
      <Rect x={160} y={0} width={80} height={180} fill="#CE1126" />
    </G>
  );
});

export default function ROFlag(props: FlagProps) {
  return (
    <Svg
      width={240}
      height={180}
      {...props}
      viewBox={FLAG_VIEW_BOX}
      preserveAspectRatio="xMidYMid meet"
    >
      <ROFlagArtwork />
    </Svg>
  );
}
