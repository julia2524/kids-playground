import * as React from "react";

import Svg, { Circle, G, Path, Polygon, Rect } from "react-native-svg";

import type { SvgProps } from "react-native-svg";

// 기존 퍼즐판과 조각이 공유하는 좌표계
export const FLAG_VIEW_BOX = "0 0 240 180";

// 태양은 기존 원본 좌표와 크기 유지
const ARTWORK_TRANSFORM = "translate(0 15) scale(0.3)";

type FlagProps = Omit<SvgProps, "children" | "viewBox" | "preserveAspectRatio">;

export const ARFlagArtwork = React.memo(function ARFlagArtwork() {
  return (
    <>
      {/* 색띠: 1:1:1 비율로 180px 전체 채우기 */}

      {/* 위쪽 하늘색: 60px */}
      <Rect x={0} y={0} width={240} height={60} fill="#74ACDF" />

      {/* 중앙 흰색: 60px */}
      <Rect x={0} y={60} width={240} height={60} fill="#FFFFFF" />

      {/* 아래쪽 하늘색: 60px */}
      <Rect x={0} y={120} width={240} height={60} fill="#74ACDF" />

      {/* 가운데의 5월의 태양: 기존 크기와 위치 유지 */}
      <G transform={ARTWORK_TRANSFORM}>
        <G transform="translate(400 250) scale(1.38)">
          <G>
            <Polygon
              points="0,-48 2.64646,-26.86999 9.36434,-47.07769 7.83769,-25.83739 18.3688,-44.34622 12.72771,-23.81187 26.66737,-39.91054 17.12862,-20.87128 33.94113,-33.94113 20.87128,-17.12862 39.91054,-26.66737 23.81187,-12.72771 44.34622,-18.3688 25.83739,-7.83769 47.07769,-9.36434 26.86999,-2.64646 48,0 26.86999,2.64646 47.07769,9.36434 25.83739,7.83769 44.34622,18.3688 23.81187,12.72771 39.91054,26.66737 20.87128,17.12862 33.94113,33.94113 17.12862,20.87128 26.66737,39.91054 12.72771,23.81187 18.3688,44.34622 7.83769,25.83739 9.36434,47.07769 2.64646,26.86999 0,48 -2.64646,26.86999 -9.36434,47.07769 -7.83769,25.83739 -18.3688,44.34622 -12.72771,23.81187 -26.66737,39.91054 -17.12862,20.87128 -33.94113,33.94113 -20.87128,17.12862 -39.91054,26.66737 -23.81187,12.72771 -44.34622,18.3688 -25.83739,7.83769 -47.07769,9.36434 -26.86999,2.64646 -48,0 -26.86999,-2.64646 -47.07769,-9.36434 -25.83739,-7.83769 -44.34622,-18.3688 -23.81187,-12.72771 -39.91054,-26.66737 -20.87128,-17.12862 -33.94113,-33.94113 -17.12862,-20.87128 -26.66737,-39.91054 -12.72771,-23.81187 -18.3688,-44.34622 -7.83769,-25.83739 -9.36434,-47.07769 -2.64646,-26.86999"
              fill="#EAB72C"
            />

            <Circle
              cx={0}
              cy={0}
              r={26}
              fill="#F6C44B"
              stroke="#9D6728"
              strokeWidth={1.7}
            />
            <Path
              d="M -16 -4 Q -10 -10 -5 -4 M 5 -4 Q 10 -10 16 -4 M 0 -2 L -2 5 H 2 M -8 10 Q 0 16 8 10"
              fill="none"
              stroke="#9D6728"
              strokeWidth={2.1}
              strokeLinecap="round"
            />
          </G>
        </G>
      </G>
    </>
  );
});

export default function ARFlag(props: FlagProps) {
  return (
    <Svg
      width={240}
      height={180}
      {...props}
      viewBox={FLAG_VIEW_BOX}
      preserveAspectRatio="xMidYMid meet"
    >
      <ARFlagArtwork />
    </Svg>
  );
}
