import React from "react";

import { I18nManager } from "react-native";

import Svg, { Circle, G, Path, Polygon } from "react-native-svg";

interface SunBadgeProps {
  type?: "full" | "half" | "empty";
  size?: number;
}

const SUN_YELLOW = "#FFD85C";
const EMPTY_COLOR = "#E2E8F0";

export default function SunBadge({ type = "empty", size = 30 }: SunBadgeProps) {
  const isRTL = I18nManager.isRTL;

  const center = size / 2;

  const sunRadius = size * 0.28;
  const innerRadius = size * 0.34;
  const outerRadius = size * 0.48;

  // 햇살 8개
  const TOTAL_RAYS = 8;

  const rays = Array.from({ length: TOTAL_RAYS }, (_, index) => {
    const angle = index * 45 + 180;

    const radian = (angle * Math.PI) / 180;

    const sideAngle = 16;

    const leftRadian = ((angle - sideAngle) * Math.PI) / 180;
    const rightRadian = ((angle + sideAngle) * Math.PI) / 180;

    const leftX = center + Math.cos(leftRadian) * innerRadius;
    const leftY = center + Math.sin(leftRadian) * innerRadius;

    const rightX = center + Math.cos(rightRadian) * innerRadius;
    const rightY = center + Math.sin(rightRadian) * innerRadius;

    const tipX = center + Math.cos(radian) * outerRadius;
    const tipY = center + Math.sin(radian) * outerRadius;

    let isFilled = false;

    if (type === "full") {
      isFilled = true;
    } else if (type === "half") {
      const normalizedAngle = (angle + 360) % 360;

      // LTR: 왼쪽 절반
      // RTL: 오른쪽 절반
      isFilled = isRTL
        ? normalizedAngle < 90 || normalizedAngle > 270
        : normalizedAngle > 90 && normalizedAngle < 270;
    }

    return {
      points: `${leftX},${leftY} ${tipX},${tipY} ${rightX},${rightY}`,
      isFilled,
    };
  });

  // 해 가운데 4조각
  const TOTAL_SLICES = 4;

  return (
    <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {/* 햇살 */}
      <G>
        {rays.map((ray, index) => (
          <Polygon
            key={index}
            points={ray.points}
            fill={ray.isFilled ? SUN_YELLOW : EMPTY_COLOR}
            strokeLinejoin="round"
          />
        ))}
      </G>

      {/* 해 가운데 원 */}
      <G>
        {Array.from({ length: TOTAL_SLICES }, (_, index) => {
          const startAngle = index * 90 + 180;
          const endAngle = startAngle + 90;

          const startRadian = (startAngle * Math.PI) / 180;
          const endRadian = (endAngle * Math.PI) / 180;

          const x1 = center + Math.cos(startRadian) * sunRadius;
          const y1 = center + Math.sin(startRadian) * sunRadius;

          const x2 = center + Math.cos(endRadian) * sunRadius;
          const y2 = center + Math.sin(endRadian) * sunRadius;

          let isFilled = false;

          if (type === "full") {
            isFilled = true;
          } else if (type === "half") {
            const midAngle = (startAngle + 45 + 360) % 360;

            // LTR: 왼쪽 2조각
            // RTL: 오른쪽 2조각
            isFilled = isRTL
              ? midAngle < 90 || midAngle > 270
              : midAngle > 90 && midAngle < 270;
          }

          return (
            <Path
              key={index}
              d={`
                M ${center} ${center}
                L ${x1} ${y1}
                A ${sunRadius} ${sunRadius} 0 0 1 ${x2} ${y2}
                Z
              `}
              fill={isFilled ? SUN_YELLOW : EMPTY_COLOR}
              stroke="none"
            />
          );
        })}
      </G>

      {/* 해 전체 테두리 */}
      <Circle cx={center} cy={center} r={sunRadius} fill="none" />
    </Svg>
  );
}
