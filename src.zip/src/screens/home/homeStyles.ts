import { Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import styled from "styled-components/native";

import { COLORS } from "../../design-system/tokens/colors";
import { AppText } from "../../utils/AppText";

export const Background = styled.View`
  flex: 1;
`;

export const BackgroundImage = styled.Image`
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
`;
// export const Container = styled(SafeAreaView)`
//   flex: 1;
// `;

// 1. styled 컴포넌트 쪽에서 Container를 일반 View로 변경
export const Container = styled.View`
  flex: 1;
`;

// --- Header ---
export const Header = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-top: ${(props) => props.theme.spacing?.md ?? 20}px;
  margin-left: 18px;
  margin-right: 18px;
  margin-bottom: 18px;
`;

export const HeaderTitleGroup = styled.View``;

export const LogoRow = styled.View`
  flex-direction: row;
  align-items: center;
`;

export const LogoStar = styled.View`
  width: 38px;
  height: 38px;
  border-radius: 14px;
  background-color: ${COLORS.yellow};
  justify-content: center;
  align-items: center;
  margin-right: 9px;
`;

export const LogoStarText = styled(AppText)`
  font-size: ${(props) => props.theme.typography.h2.fontSize}px;
  color: ${COLORS.white};
`;

export const LogoText = styled(AppText)`
  font-size: ${(props) => props.theme.typography.h3.fontSize}px;
  line-height: ${(props) => props.theme.typography.body.lineHeight}px;
  font-weight: ${(props) => props.theme.typography.h3.fontWeight};
  color: ${COLORS.purple};
`;

export const HeaderSubText = styled(AppText)`
  margin-top: 3px;
  font-size: ${(props) => props.theme.typography.caption.fontSize}px;
  color: ${COLORS.purple};
`;

export const IconButton = styled.TouchableOpacity`
  width: 48px;
  height: 48px;
  border-radius: 24px;
  background-color: ${COLORS.purple};
  align-items: center;
  justify-content: center;
  shadow-color: #000;
  shadow-opacity: 0.08;
  shadow-radius: 8px;
  shadow-offset: 0px 3px;
  elevation: 3;
`;

// --- Hero ---
export const HeroCard = styled.View`
  margin: 0px 18px 20px;
`;

export const HeroTextArea = styled.View`
  z-index: 2;
`;

export const HeroTitle = styled(AppText)`
  font-size: ${(props) => props.theme.typography.learningTitle.fontSize}px;
  line-height: ${(props) => props.theme.typography.learningTitle.lineHeight}px;
  font-family: ${(props) => props.theme.fontFamily};
  color: ${COLORS.text};
`;

export const HeroDescription = styled(AppText)`
  font-size: ${(props) => props.theme.typography.bodySmall.fontSize}px;
  line-height: ${(props) => props.theme.typography.bodySmall.lineHeight}px;
  color: ${COLORS.secondaryText};
`;

// --- Filter ---
export const FilterRow = styled.View`
  flex-direction: row;
  gap: 8px;
  margin-top: 18px;
  margin-left: 18px;
  margin-right: 18px;
  margin-bottom: 18px;
`;

export const FilterButton = styled.TouchableOpacity<{ active?: boolean }>`
  flex: 1;
  min-height: 52px;
  border-radius: 18px;
  background-color: ${(props) => (props.active ? COLORS.purple : COLORS.white)};
  align-items: center;
  justify-content: center;
  padding-horizontal: 4px;
  shadow-color: #000;
  shadow-opacity: 0.06;
  shadow-radius: 6px;
  shadow-offset: 0px 2px;
  elevation: 2;
`;

export const FilterText = styled(AppText)<{ active?: boolean }>`
  margin-top: 3px;
  font-size: 11px;
  font-family: ${(props) => props.theme.fontFamily};
  color: ${(props) => (props.active ? COLORS.white : COLORS.secondaryText)};
`;

// --- Game Grid & Cards ---
export const GameGrid = styled.View`
  width: 95%;
  align-self: center;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-between;
  row-gap: 14px;
`;

export const GameCard = styled.TouchableOpacity<{ bgColor: string }>`
  width: 48.2%;
  aspect-ratio: 0.88;
  border-radius: 25px;
  overflow: hidden;
  padding: 13px;
  background-color: ${(props) => props.bgColor};
  border-width: 2px;
  border-color: ${COLORS.white};
  shadow-color: #000;
  shadow-opacity: 0.09;
  shadow-radius: 9px;
  shadow-offset: 0px 4px;
  elevation: 3;
`;

export const CardIllustration = styled.View`
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const IllustrationText = styled(AppText)<{ isSmall?: boolean }>`
  font-size: ${(props) => (props.isSmall ? "16px" : "57px")};
  margin-top: ${(props) => (props.isSmall ? "-6px" : "0px")};
`;

export const IllustrationSmallText = styled(AppText)`
  margin-top: -6px;
  font-size: 16px;
`;

export const CardBottom = styled.View`
  min-height: 58px;
  border-radius: 17px;
  background-color: ${COLORS.white};
  padding-left: 11px;
  padding-right: 11px;
  padding-top: 10px;
  padding-bottom: 10px;
  align-items: center;
  justify-content: space-between;
`;

export const CardTitle = styled(AppText)`
  font-size: ${(props) => props.theme.typography.body.fontSize}px;
  font-family: ${(props) => props.theme.fontFamily};
  color: ${COLORS.text};
`;

export const CardDescription = styled(AppText)`
  font-size: 11px;
  color: ${COLORS.secondaryText};
`;

export const ArrowCircle = styled.View`
  width: 31px;
  height: 31px;
  border-radius: 16px;
  background-color: #f7f7fb;
  justify-content: center;
  align-items: center;
`;

// --- Coming Soon ---
export const ComingSoon = styled.TouchableOpacity`
  margin-top: 18px;
  min-height: 58px;
  border-radius: 22px;
  background-color: ${COLORS.white};
  align-items: center;
  justify-content: center;
  border-width: 1px;
  border-color: #e8e4f5;
`;

export const ComingSoonEmoji = styled(AppText)`
  font-size: ${(props) => props.theme.typography.body.fontSize}px;
  margin-bottom: 3px;
`;

export const ComingSoonText = styled(AppText)`
  font-size: ${(props) => props.theme.typography.caption.fontSize}px;
  font-weight: ${(props) => props.theme.typography.button.fontWeight};
  color: ${COLORS.secondaryText};
`;

// --- Footer ---
export const Footer = styled.View`
  margin-top: 20px;
  height: 68px;
  border-radius: 25px;
  background-color: ${COLORS.white};
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  shadow-color: #000;
  shadow-opacity: 0.07;
  shadow-radius: 8px;
  shadow-offset: 0px 3px;
  elevation: 3;
`;

export const FooterItem = styled.TouchableOpacity`
  align-items: center;
  justify-content: center;
  min-width: 60px;
`;

export const FooterText = styled(AppText)<{ active?: boolean }>`
  margin-top: 2px;
  font-size: 11px;
  font-weight: ${(props) => props.theme.typography.bodyLarge.fontWeight};
  color: ${(props) => (props.active ? COLORS.purple : COLORS.muted)};
`;

// --- Decoration Elements ---
export const Star = styled.View<{ starType: "star1" | "star2" | "star3" }>`
  position: absolute;
  width: 7px;
  height: 7px;
  border-radius: 4px;
  opacity: 0.8;

  ${(props) =>
    props.starType === "star1"
      ? `
        top: 110px;
        right: 26px;
        background-color: ${COLORS.yellow};
      `
      : ""}

  ${(props) =>
    props.starType === "star2"
      ? `
        top: 290px;
        left: 13px;
        background-color: ${COLORS.pink};
      `
      : ""}

  ${(props) =>
    props.starType === "star3"
      ? `
        top: 540px;
        right: 12px;
        background-color: ${COLORS.mint};
      `
      : ""}
`;

export const DecorationPlanet = styled.View<{
  planetType: "planet1" | "planet2";
}>`
  position: absolute;
  border-radius: 999px;
  opacity: 0.25;

  ${(props) =>
    props.planetType === "planet1"
      ? `
        width: 100px;
        height: 100px;
        right: -48px;
        top: 170px;
        background-color: ${COLORS.blue};
      `
      : ""}

  ${(props) =>
    props.planetType === "planet2"
      ? `
        width: 70px;
        height: 70px;
        left: -35px;
        top: 630px;
        background-color: ${COLORS.pink};
      `
      : ""}
`;

// export const BottomTab = styled.View<{ bottomInset: number }>`
//   position: absolute;
//   bottom: ${(props) => Math.max(props.bottomInset, 12) + 8}px;
//   left: 16px;
//   right: 16px;

//   height: 64px;
//   background-color: ${COLORS.white};

//   flex-direction: row;
//   justify-content: space-around;
//   align-items: center;

//   border-radius: 32px;

//   shadow-color: #5d5193;
//   shadow-opacity: 0.12;
//   shadow-radius: 12px;
//   shadow-offset: 0px 4px;
//   elevation: 6;
// `;

export const BottomTab = styled.View<{ bottomInset: number }>`
  position: absolute;
  bottom: ${(props) => Math.max(props.bottomInset, 12)}px;
  left: 16px;
  right: 16px;

  height: 64px;
  background-color: ${COLORS.white};

  flex-direction: row;
  justify-content: space-around;
  align-items: center;

  border-radius: 32px;

  shadow-color: #5d5193;
  shadow-opacity: 0.12;
  shadow-radius: 12px;
  shadow-offset: 0px 4px;
  elevation: 6;
  z-index: 20;
`;

export const TabItem = styled.TouchableOpacity<{ active?: boolean }>`
  align-items: center;
  justify-content: center;
`;

export const TabLabel = styled(AppText)<{ active?: boolean }>`
  font-size: 11px;
  font-family: ${(props) => props.theme.fontFamily};
  color: ${(props) => (props.active ? COLORS.purple : COLORS.muted)};
  margin-top: 3px;
`;

export const CardImage = styled(Image)`
  flex: 1;
  width: 100%;
`;
